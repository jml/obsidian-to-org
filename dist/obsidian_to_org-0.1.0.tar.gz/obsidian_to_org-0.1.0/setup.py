# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['obsidian_to_org']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['obsidian-to-org = obsidian_to_org.__main__:single_file',
                     'obsidian-to-org-roam = '
                     'obsidian_to_org.__main__:convert_directory']}

setup_kwargs = {
    'name': 'obsidian-to-org',
    'version': '0.1.0',
    'description': 'Convert Obsidian Markdown files to org-roam',
    'long_description': "# obsidian-to-org\n\nConvert Obsidian files to org-roam\n\nBased on @rberaldo's [pioneering work](https://gist.github.com/rberaldo/2a3bd82d5ed4bc39fee7e8ff4a6242b2).\n\nSee also\n\nhttps://org-roam.discourse.group/t/fully-migrating-from-obsidian/1708\n\nhttps://emacs-china.org/t/obsidian-to-org-python/23125\n\n## How\n\nInstall requirements/dependencies\n\n```shell\ncd obsidian-to-org/\npoetry install\n```\n\n(Optional) Build obsidian-to-org if dist/ doesn't exists\n\n```shell\npoetry build\n```\n\nInstall obsidian-to-org\n\n```\ncd dist/\npip3 install obsidian_to_org-0.1.0-py3-none-any.whl\n```\n\n## Help\n\n```shell\n$ obsidian-to-org --help\nusage: obsidian-to-org [-h] markdown_file\n\nConvert an Obsidian Markdown file into org-mode\n\npositional arguments:\n  markdown_file  The Markdown file to convert\n\noptions:\n  -h, --help     show this help message and exit\n```\n\n## Misc\n\n\n",
    'author': 'Jonathan Lange',
    'author_email': 'jml@mumak.net',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
